#include <stdio.h>
int main()
{
	
	int i, j, n=10;

	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j==n)
				printf("*");
			else if(i==n)
				printf("*");
			else if(j>=n-i+1)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j==n)
				printf("*");
			else if(i==n)
				printf("*");
			else if(j<=i+1)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	

	return 0;
}
