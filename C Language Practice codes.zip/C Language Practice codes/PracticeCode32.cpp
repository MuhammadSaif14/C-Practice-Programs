#include <stdio.h>
int leap(int year);
int total_dys(int year, int leaps);
int remaining(int total);
int main() {
    int year, leaps, total, r;

    printf("Enter the year: ");
    scanf("%d", &year);

    leaps = leap(year);
    total = total_dys(year, leaps);
    r = remaining(total);

    printf("1st January %d is ", year);

    if (r == 0)
        printf("Monday");
    else if (r == 1)
        printf("Tuesday");
    else if (r == 2)
        printf("Wednesday");
    else if (r == 3)
        printf("Thursday");
    else if (r == 4)
        printf("Friday");
    else if (r == 5)
        printf("Saturday");
    else
        printf("Sunday");

    return 0;
}
int leap(int year)
{
	return (year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400;
}
int total_dys(int year, int leaps)
{
	return  (year - 1) * 365 + leaps;
}
int remaining(int total)
{
	return total % 7;
}
