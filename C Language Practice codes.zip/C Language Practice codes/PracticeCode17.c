#include <stdio.h>
#include <math.h>
double get_radius(int x, int y);
double get_angle(int x, int y);
int main(){

	int x, y;
	double  angle, r;
	
	printf("Enter the Cartesian Co-ordinate value of x: ");	
	scanf("%d", &x);
	printf("Enter the Cartesian Co-ordinate value of y: ");	
	scanf("%d", &y);
	
	r = get_radius(x, y);
	angle = get_angle(x, y);
	
	printf("The polar Co-ordinates are: (%f , %f)", r, angle);

	return 0;
}
double get_radius(int x, int y)
{
	return sqrt((x * x) + (y * y));
}
double get_angle(int x, int y)
{
	return atan((double)y/x) * 180 / M_PI;
}
