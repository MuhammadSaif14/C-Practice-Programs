#include <stdio.h>
#include <math.h>
float distance(int x1, int y1, int x2, int y2);
int main() {

//  Distance less than the radius ? point is inside the circle
//	Distance equal to the radius ? point is on the circle
//	Distance greater than the radius ? point is outside the circle

	float x1,y1,x2,y2, r, d;
	
	printf("Enter (x1,y1): \n");
	scanf("%f %f", &x1, &y1);
	printf("Enter (x2,y2): \n");
	scanf("%f %f", &x2, &y2);
	printf("Enter Radius: \n");
	scanf("%f", &r);
	
	d = distance(x1,y1,x2,y2);
	
	if (d < r)
        printf("The point lies INSIDE the circle.");
    else if (d == r)
        printf("The point lies ON the circle.");
    else
        printf("The point lies OUTSIDE the circle.");

    return 0;
}
float distance(int x1, int y1, int x2, int y2)
{
	return sqrt(pow(x2 - x1, 2) + pow(y2-y1, 2));
}
