#include <stdio.h>
void youngest(int ram, int shyam, int ajay);
int main(){

	int ram, shyam, ajay;
	
	printf("Enter the age of Ram: ");
	scanf("%d", &ram);
	printf("Enter the age of Shyam: ");
	scanf("%d", &shyam);
	printf("Enter the age of Ajay: ");
	scanf("%d", &ajay);
	
	youngest(ram, shyam, ajay);
		
	return 0;
}
void youngest(int ram, int shyam, int ajay)
{
	if(ram < shyam){
		if(ram < ajay)
			printf("Ram is youngest");
		else
			printf("Ajay is youngest");
	}else{
		if(shyam < ajay){
			if(shyam < ram)
				printf("Shyam is youngest");
		}else
			printf("Ram is youngest");	
	}
}

