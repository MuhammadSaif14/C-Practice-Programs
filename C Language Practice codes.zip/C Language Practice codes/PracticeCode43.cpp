#include <stdio.h>
int main()
{
	
	int i, j, n=4, m=1;


	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j<=i)
				printf("%d ", m++);
			else
				printf(" ");
			
			
		}
		printf("\n");
	}
		

	return 0;
}
