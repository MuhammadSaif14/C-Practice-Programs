#include <stdio.h>
#include <math.h>
int location_c(int D);
int location_d(int E);
int location_e(int temp);
int main(){

	int C, D, E, temp;
	printf("Enter Location C: ");
	scanf("%d", &C);
	printf("Enter Location D: ");
	scanf("%d", &D);
	printf("Enter Location E: ");
	scanf("%d", &E);
	
	temp = C;
	C = location_c(D);
	D = location_d(E);
	E = location_e(temp);
	
	printf("\nLocation C is now: %d\n", C);
	printf("Location D is now: %d\n", D);
	printf("Location E is now: %d", E);

	return 0;
}
int location_c(int D)
{
	return D;
}
int location_d(int E)
{
	return E;
}
int location_e(int temp)
{
	return temp;
}
