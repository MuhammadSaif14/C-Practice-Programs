#include <stdio.h>
int main()
{
	
	int i, j, n=5;

	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(i==j)
				printf("*");
			else if(j==1)
				printf("*");
			else if(i==1)
				printf("*");
			else if((j == (n+1)-i))
				printf("*");
			else if(j==n)
				printf("*");
			else if(i==n)
				printf("*");
			else 
				printf(" ");
		}
		printf("\n");
	}
		

	return 0;
}
