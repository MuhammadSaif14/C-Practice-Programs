#include <stdio.h>
int main(){
	
	float bs, da, hra, grs;
	
	printf("Enter the employees salary: ");
	scanf("%f", &bs);
	
	if(bs < 1500){
		hra = bs * 10/100;
		da = bs * 90/100;
	}
	else {
		hra = 500; 
		da = bs * 90/100;
	}
	
	grs = bs + da + hra;
	
	printf("Gross salary = Rs.%f", grs);
	
	return 0;
}
