#include <stdio.h>
#include <math.h>
int main(){
	
	/*
	If lengths of three sides of a triangle are input through the keyboard,
	write a program to find the area of the triangle.
	*/
	
	float a, b, c, area, s;
	printf("Enter the length of the three sides if triangle: ");
	scanf("%f %f %f", &a, &b, &c);
		
	s = (a+b+c)/2;
	area = sqrt(s*(s-a) * (s-b) * (s-c));
	
	printf("%f", area);
	
	return 0;

}
