#include<stdio.h>
int main()
{
	int i,j,n,cols,rows;
	printf("Enter a number: ");
	scanf("%d", &n);
	
	
	if((n>0) && (n % 2 == 0 ) && (n<=10))
	{
		rows = 2*n-1;
		for(i=1;i<=rows;i++)
		{
			if(i<=n)
				cols=i;
			else
				cols = rows-i+1;
			for(j=1;j<=cols;j++)
			{
				if(j==1 || j==cols)
					printf("*");
				else
					printf("%d", j-1);
			}
			printf("\n");
		}
	}
	else
		printf("Error!");
		
	
	
	return 0;
}
