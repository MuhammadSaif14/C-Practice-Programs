#include <stdio.h>
int main(){
	
	/*
	Write a program in C that

	Initialize character variables with the letters in	
	your first name
	
	Display the ASCII values of each of those
	characters on separate 
	*/

	char m ='M', u ='U', h ='H', a ='A', d ='D', s ='S', i ='I', f ='F';
	
	printf("The ASCII value of '%c' is %d\n", m, m);
	printf("The ASCII value of '%c' is %d\n", u, u);
	printf("The ASCII value of '%c' is %d\n", h, h);
	printf("The ASCII value of '%c' is %d\n", a, a);
	printf("The ASCII value of '%c' is %d\n", m, m);
	printf("The ASCII value of '%c' is %d\n", m, m);
	printf("The ASCII value of '%c' is %d\n", a, a);
	printf("The ASCII value of '%c' is %d\n\n", d, d);
	
	printf("The ASCII value of '%c' is %d\n", s, s);
	printf("The ASCII value of '%c' is %d\n", a, a);
	printf("The ASCII value of '%c' is %d\n", i, i);
	printf("The ASCII value of '%c' is %d\n", f, f);
	
	return 0;
}
