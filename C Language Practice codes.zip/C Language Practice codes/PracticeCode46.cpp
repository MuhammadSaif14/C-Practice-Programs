#include<stdio.h>
int main()
{
	int i,j,k,n=4, m=1;
	char l = 'A';
	
	for(i-1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++) printf(" ");
		for(j=1;j<=i;j++) printf("%c",  l++);
		for(k=1;k<=i;k++) printf("%d", m++);
		
		printf("\n");
	}
	
	
	
	return 0;
}
