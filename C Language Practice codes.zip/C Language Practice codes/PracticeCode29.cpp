#include <stdio.h>
float straight_left(float x1, float y1, float x2, float y2, float x3, float y3);
float straight_right(float x1, float y1, float x2, float y2, float x3, float y3);
int main() {
    float x1, y1, x2, y2, x3, y3;
    float left, right;

    printf("Enter x1 and y1: ");
    scanf("%f %f", &x1, &y1);

    printf("Enter x2 and y2: ");
    scanf("%f %f", &x2, &y2);

    printf("Enter x3 and y3: ");
    scanf("%f %f", &x3, &y3);

    left  = straight_left(x1, y1, x2, y2, x3, y3);
    right = straight_right(x1, y1, x2, y2, x3, y3);

    if (left == right)
        printf("The points are on one straight line.");
    else
        printf("The points are NOT on one straight line.");

    return 0;
}
float straight_left(float x1, float y1, float x2, float y2, float x3, float y3)
{
	return (y2 - y1) * (x3 - x2);
}
float straight_right(float x1, float y1, float x2, float y2, float x3, float y3)
{
	return (y3 - y2) * (x2 - x1);
}
