#include<stdio.h>
int main()
{
	int i,j,k,n=3, m=1;
	char l = 'A';
	
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++) printf(" ");
		for(j=1;j<=2*i-1;j++) printf("%d",  m++);
		
		
		printf("\n");
	}
	
	
	
	return 0;
}
