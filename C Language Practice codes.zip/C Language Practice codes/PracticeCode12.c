#include <stdio.h>
int main(){
	
	
	int hrs_travelled, distance_travelled, speed;
	
	
	
	
	
	
	
	
	
	
	return 0;
}
