#include <stdio.h>
int main()
{
	
	int i, j, n=51;
	char l;

	for(i=1;i<=n/2+1;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j >= ((n/2 + 1)+1)-i && j <= (((n/2 + 1))-1)+i)
				printf("%c", 64+i);
			else
				printf(" ");
		}
		printf("\n");
	}
		

	return 0;
}
