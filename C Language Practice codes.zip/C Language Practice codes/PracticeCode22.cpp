#include <stdio.h>
float profit(float sp, float cp);
float loss(float sp, float cp);
int main(){

	float sp,cp,P,L;
	
	printf("Enter Cost Price: ");
	scanf("%f", &cp);
	printf("Enter Selling Price: ");
	scanf("%f", &sp);

	P = profit(sp, cp);
	L = loss(sp, cp);
	
	if(P > 0)
		printf("You made profit of Rs.%f", P);
	if(L > 0)
		printf("You made profit of Rs.%f", P);
	if(P == 0)
		printf("No Profit, No Loss");
	
	return 0;
}
float profit(float sp, float cp)
{
	return sp - cp;
}
float loss(float sp, float cp)
{
	return cp - sp;
}
