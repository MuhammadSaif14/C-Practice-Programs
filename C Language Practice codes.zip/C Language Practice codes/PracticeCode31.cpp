#include <stdio.h>
void quadrant(float x, float y);
int main() {
    float x, y;

    printf("Enter the point (x y): ");
    scanf("%f %f", &x, &y);
	
	quadrant(x,y);
    
    return 0;
}
void quadrant(float x, float y)
{
	if (x == 0) {
        if (y == 0)
            printf("The point is the ORIGIN.");
        else
            printf("The point lies on the Y-axis.");
    }
    else {
        if (y == 0)
            printf("The point lies on the X-axis.");
        else
            printf("The point is not on any axis.");
    }
}
