#include <stdio.h>
#include <math.h>
float tan_theta(float angle);
float sin_theta(float angle);
float cos_theta(float angle);
int main()
{

	float angle, sn, cs, tn;
	
	printf("Enter the angle: ");
	scanf("%f", &angle);
	
	tn = tan_theta(angle);
	sn = sin_theta(angle);
	cs = cos_theta(angle);
	
	printf("sin = %f \ncos = %f \ntan = %f", sn,cs,tn);
	

	return 0;
}
float tan_theta(float angle)
{
	return tan(angle * M_PI / 180);
}
float sin_theta(float angle)
{
	return sin(angle * M_PI / 180);
}
float cos_theta(float angle)
{
	return cos(angle * M_PI / 180);
}
