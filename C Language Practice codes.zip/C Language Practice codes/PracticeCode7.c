#include <stdio.h>
#include <math.h>

int main(){
	
	int base = 2;
	int power = 3;
	int a = pow(base, power);
	
	printf("%d", a);
	
	
	
	return 0;
}
