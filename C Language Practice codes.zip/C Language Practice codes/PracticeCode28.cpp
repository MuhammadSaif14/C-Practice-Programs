#include <stdio.h>
int area(int L, int W);
int perimeter(int L, int W);
int main() {
    
    int L, W, A, P;
    
    printf("Enter Length and Width of Rectangle: \n");
    scanf("%d %d", &L, &W);
    
    A = area(L, W);
    P = perimeter(L,W);
    
    printf("\nArea: %d\n", A);
    printf("Perimeter: %d\n", P);
    
    if(A > P)
    	printf("The Area is greater than the perimeter of Rectangle.");
    else 
    	printf("The Perimeter is greater than the Area of Rectangle.");
    
    return 0;
}
int area(int L, int W)
{
	return L * W;
}
int perimeter(int L, int W)
{
	return 2 * (L + W);
}
