#include <stdio.h>
int main(){
	
	/*
	If the marks obtained by a student in five different subjects are input
	through the keyboard, write a program to find out the aggregate marks
	and percentage marks obtained by the student. Assume that the
	maximum marks that can be obtained by a student in each subject is
	100. 
	*/
	
	int AC, AP, PF, FE, PS, aggr;
	float prcntage;
	
	printf("Enter the 5 sunjects marks: \n");
	scanf("%d %d %d %d %d",&AC, &AP, &PF, &FE, &PS);
	aggr = AC+AP+PF+FE+PS;
	prcntage = aggr / 5;
	
	printf("Aggregate Marks: %d\n", aggr);
	printf("Percentage Marks: %.2f", prcntage);
	
	 
	
	
	
	
	return 0;
}
