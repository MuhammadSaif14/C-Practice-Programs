#include <stdio.h>
int main()
{
	
	int i, j, n=10;

	for(i=1;i<=n/2;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(i==1)
				printf("*");
			else if(j==1)
				printf("*");
			else if(j==n)
				printf("*");
			else if(i==n/2) 
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	

	return 0;
}
