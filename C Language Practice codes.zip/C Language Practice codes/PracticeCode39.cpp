#include <stdio.h>
int main()
{
	
	int i, j, n=10;

	for(i=1;i<=n/2;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j==n/2)
				printf("*");
			else if(i==n/3)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	

	return 0;
}
