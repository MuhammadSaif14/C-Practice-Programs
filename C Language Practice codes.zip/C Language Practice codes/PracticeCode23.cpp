#include <stdio.h>
int leap_year(int year);
int main(){

	int year;
	
	printf("Enter year: ");
	scanf("%d", &year);
	
	leap_year(year);
	
	return 0;
}
int leap_year(int year)
{
	if(year % 100 == 0){
		if(year % 400 == 0)
			printf("It is a Leap year");
		else
			printf("Not a Leap year");
	}else{
		if(year % 4 == 0)
			printf("It is a Leap year");
		else
			printf("Not a Leap year");
	}
	
}

