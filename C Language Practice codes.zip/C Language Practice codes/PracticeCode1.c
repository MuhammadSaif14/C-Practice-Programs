#include <stdio.h>
int main(){
	
	int house_no = 22;
	float FSc = 75.45;
	char peshawar = 'N';
	
	printf("house no: %d \n", house_no);
	printf("FSC percentage: %.2f \n", FSc);
	printf("Are you from peshawar: %c \n", peshawar);
	
	return 0;
}
