#include<stdio.h>
int sum_of_digits(int n);
int main()
{
	int n, total;
	
	printf("Enter the 5 digit number: ");
	scanf("%d", &n);
	
	total = sum_of_digits(n);

	printf("The sum of of your given 5 digits is: %d", total);
	
	
	return 0;
}
int sum_of_digits(int n)
{
	int d1,d2,d3,d4,d5;
	
	d5 = n % 10;
	n = n / 10;
	d4 = n % 10;
	n = n / 10;
	d3 = n % 10;
	n = n / 10;
	d2 = n % 10;
	n = n / 10;
	d1 = n % 10;

	return d5 + d4 + d3 + d2 + d1;

}
