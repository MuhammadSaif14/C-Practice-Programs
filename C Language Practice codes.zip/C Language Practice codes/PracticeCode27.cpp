#include <stdio.h>
float absolute_value(float num, float absolute);
int main() {
    float num, absolute;

    printf("Enter a number: ");
    scanf("%f", &num);

    absolute = absolute_value(num, absolute);
        
    printf("Absolute value = %f", absolute);

    return 0;
}
float absolute_value(float num, float absolute)
{
	if (num < 0)
        return -num;    
    else
        return num; 
}
