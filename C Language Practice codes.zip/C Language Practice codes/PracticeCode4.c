#include <stdio.h>
int main(){
	
	/*
	Ramesh�s basic salary is input through the keyboard. His dearness
	allowance is 40% of basic salary, and house rent allowance is 20% of
	basic salary. Write a program to calculate his gross salary. 
	*/
	
	float bs, da, hra, grs;
	
	printf("Enter the salary of Ramesh: ");
	scanf("%f", &bs);
	
	da = 0.4 * bs;
	hra = 0.2 * bs;
	grs = bs + da + hra;
	
	printf("Basic salary of Ramesh is: %.2f\n", bs);
	printf("His dearenss allowance is: %.2f\n", da);
	printf("His house rent allowance is: %.2f\n", hra);
	printf("Gross salary of Ramesh is: %.2f", grs);
	
	
	
	
	
	return 0;
}
