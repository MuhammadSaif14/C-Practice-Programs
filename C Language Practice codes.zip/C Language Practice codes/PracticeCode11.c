#include <stdio.h>
#include <math.h>
int main(){
	
	float celsius, farenheit;
	
	printf("Enter the Celsius value: ");
	scanf("%f", &celsius);
	
	farenheit = 1.8 * celsius + 32;
	
	printf("Celsius: %f \n", celsius);
	printf("Farenheit: %f \n", farenheit);
	
	
	
	return 0;
	
}
