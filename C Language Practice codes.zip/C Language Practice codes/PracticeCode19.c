#include <stdio.h>
#include <math.h>
float wind_chill_factor(float t, float v);
int main(){

	float t, v, wcf;
	
	printf("Enter Temperature: ");
	scanf("%f", &t);
	printf("Enter Wind velocity: ");
	scanf("%f", &v);
	
	wcf = wind_chill_factor(t, v);
	
	printf("The Wind Chill Factor is: %f", wcf);
	

	return 0;
}
float wind_chill_factor(float t, float v)
{
	return 35.74 + (0.6215 * t) + (0.4275 * t- 35.75) * pow(v, 0.16);
}
