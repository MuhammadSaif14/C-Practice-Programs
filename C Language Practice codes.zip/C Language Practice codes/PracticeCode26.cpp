#include <stdio.h>
int valid_triangle(int a, int b, int c, int sum);
int main(){

	int a,b,c, sum;
	
	printf("Enter all three angles A,B & C: \n");
	scanf("%d %d %d", &a,&b,&c);
	
	valid_triangle(a,b,c,sum);
	
	return 0;
}
int valid_triangle(int a, int b, int c, int sum)
{
	sum = a+b+c;
	
	if(sum == 180)
		printf("Valid trianlge");
	else
		printf("Not a Valid Triangle");
}

