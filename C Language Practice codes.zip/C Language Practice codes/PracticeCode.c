#include <stdio.h>
int main(){
	
	int a, b, c;
	
	printf("Enter you first value: ");
	scanf("%d", &a);
	
	printf("ENter your second value: ");
	scanf("%d", &b);
	
	c = a + b;
	
	printf("The sum of both values is: %d \n", c);
//	

//  DISPLAYING SIZE OF INT, FLOAT 

	printf("memory occupied by character: %d byte \n", (int)sizeof(int));
	printf("memory occupied by character: %d byte \n", (int)sizeof(float));
	printf("memory occupied by character: %d byte \n", (int)sizeof(char));
	

	
	return 0;
}
