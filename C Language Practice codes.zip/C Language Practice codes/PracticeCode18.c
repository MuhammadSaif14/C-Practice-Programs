#include <stdio.h>
#include <math.h>
double distance(double L1,double L2,double G1,double G2);
int main(){

	double D, L1, L2, G1, G2;
	
	printf("Enter latitude of first place (L1): ");
	scanf("%lf", &L1);
	
	printf("Enter latitude of second place (L2): ");
	scanf("%lf", &L2);
	
	printf("Enter longitude of first place (G1): ");
	scanf("%lf", &G1);
	
	printf("Enter longitude of second place (G2): ");
	scanf("%lf", &G2);
	
	D = distance(L1,L2,G1,G2);
	
	printf("Distance between the two places = %.2lf nautical miles\n", D);	
	

	return 0;
}
double distance(double L1,double L2,double G1,double G2)
{
	return 3963 * acos(sin(L1 * M_PI / 180) * sin(L2 * M_PI / 180)+ cos(L1 * M_PI / 180) * cos(L2 * M_PI / 180)* cos((G2 - G1) * M_PI / 180));
}
