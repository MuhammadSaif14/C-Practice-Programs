#include <stdio.h>
int reversed_n(int d5, int d4,int d3,int d2,int d1,int N,int originalN);
int main(){

	int d5,d4,d3,d2,d1, N, originalN, revN;
	
	printf("Enter 5  digit number: ");
	scanf("%d", &N);
	
	revN = reversed_n(d5,d4,d3,d2,d1,N,originalN);
	
	printf("Reversed Number: %d\n", revN);
	
	if(originalN == revN)
		printf("The original number and reversed nummber are equal");
	else
		printf("The original number and reversed nummber are not equal");
			
	return 0;
}
int reversed_n(int d5, int d4,int d3,int d2,int d1,int N, int originalN)
{
	originalN = N;
	
	d5 = N % 10;
	N = N / 10;
	d4 = N % 10;
	N = N / 10;
	d3 = N % 10;
	N = N / 10;
	d2 = N % 10;
	N = N / 10;
	d1 = N % 10;
	
	return  d5 * 10000 + d4 * 1000 + d3 * 100 + d2 * 10 + d1;
}

