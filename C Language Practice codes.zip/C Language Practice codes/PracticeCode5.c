#include <stdio.h>
int main(){
	
	/*
	The distance between two cities (in kilometers) is input through the
	keyboard. Write a program to convert and print this distance in meters,
	feet, inches and centimeters. 	
	*/
	
	float km, m ,ft, inch, cm;
	
	printf("Enter the distance in Kilometers: ");
	scanf("%f", &km);
	m = km * 1000;
	cm = m * 100;
	inch = cm / 2.54;
	ft = inch /12;
	
	printf("Distance in Meters is: %.2f \n", m);
	printf("Distance in Centimeters is: %.2f \n", cm);
	printf("Distance in Inches is: %.2f \n", inch);
	printf("Distance in feets is: %.2f", ft);
	
	
	
	
	return 0;
}
