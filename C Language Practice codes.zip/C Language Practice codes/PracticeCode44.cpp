#include <stdio.h>
int main()
{
	int rows = 5;
	int i, j, n=5;
	char l;

	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n-i;j++)
		printf("  ");
		
		for(j=1;j<=2*i-1;j++)
		printf("* ");
		
		printf("\n");
	}
	

    // This loop for traverse
    // pyramid from top to bottom
    for (int i = 0; i < rows; i++) {

        // Inner loop for printing 
        // character in each rows
        for (int j = 0; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }	
	for (int i = 0; i < rows; i++) {

        // Inner loop for printing 
        // character in each rows
        for (int j = 0; j <= i; j++) {
            printf("%c ", 'A' + j);
        }
        printf("\n");
    }
    
    for (int i = 0; i < rows; i++)
    {

        // This loop for printing leading whitespaces
        for (int j = 0; j < 2 * (rows - i) - 1; j++)
        {
            printf(" ");
        }

        // This loop for printing * character in each row
        for (int k = 0; k <= i; k++)
        {
            printf("* ");
        }
        printf("\n");
    }
    for (int i = 0; i < rows; i++)
    {

        // Inner loop to print the * in each row
        for (int j = 0; j < rows - i; j++)
        {
            printf("* ");
        }
        printf("\n");
    }
	
	for (int i = 0; i < rows; i++)
    {

        // First inner loop printing leading white spaces
        for (int j = 0; j < 2 * i; j++)
        {
            printf(" ");
        }

        // Second inner loop printing stars *
        for (int k = 0; k < 2 * (rows - i) - 1; k++)
        {
            printf("* ");
        }
        printf("\n");
    }
	for (int i = 0; i < rows; i++)
    {

        // First inner loop to print white spaces
        for (int j = 0; j < rows - i - 1; j++)
            printf(" ");

        // Second inner loop to print * star in each row
        for (int k = 0; k < rows; k++)
            printf("* ");
        printf("\n");
    }
    for (int i = 0; i < 2 * rows - 1; i++)
    {

        // Assigning comparator
        int comp;
        if (i < rows)
            comp = 2 * i + 1;
        else
            comp = 2 * (2 * rows - i) - 3;

        // First inner loop to print leading spaces
        for (int j = 0; j < comp; j++)
            printf(" ");

        // Second inner loop to print star *
        for (int k = 0; k < 2 * rows - comp; k++)
            printf("* ");
        printf("\n");
    }
    for (int i = 1; i <= rows; i++) {

        // Inner loop 1 for leading 
        // white spaces
        for (int j = 0; j < rows - i; j++) 
            printf(" ");
        
        // coefficient
        int C = 1; 

        // Inner loop 2 for 
        // printing numbers
        for (int k = 1; k <= i; k++) {
            printf("%d ", C);
            C = C * (i - k) / k;
        }
        printf("\n");
    }
	return 0;
}
