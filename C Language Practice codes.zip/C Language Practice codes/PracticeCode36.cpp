#include <stdio.h>
int main()
{
	
	int i, j, n=21;

	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n/2+1;j++)
		{
			if(j==1)
				printf("*");
			else if(i==j)
				printf("*");
			else if(i<=n-j+1 && i>=j+1) 
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	

	return 0;
}
