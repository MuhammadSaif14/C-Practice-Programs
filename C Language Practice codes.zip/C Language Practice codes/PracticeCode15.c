#include <stdio.h>

int main() {
    int pennies, quarters = 0, dimes = 0, nickels = 0;

    printf("Enter the number of pennies: ");
    scanf("%d", &pennies);

    printf("\nAli has %d pennies\n\n", pennies);

    while (pennies >= 25) {
        quarters++;
        pennies = pennies - 25;
    }

    while (pennies >= 10) {
        dimes++;
        pennies = pennies - 10;
    }

    while (pennies >= 5) {
        nickels++;
        pennies = pennies - 5;
    }

    printf("Quarters: %d\n", quarters);
    printf("Dimes: %d\n", dimes);
    printf("Nickels: %d\n", nickels);
    printf("Pennies: %d\n\n", pennies);

    int total = quarters + dimes + nickels + pennies;

    printf("Now Ali has %d coins", total);

    return 0;
}
