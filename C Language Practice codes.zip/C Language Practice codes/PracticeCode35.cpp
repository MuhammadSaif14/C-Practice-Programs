#include <stdio.h>
int main()
{
	
	int i, j, n=21, m=11;

	for(i=1;i<=n/2+1;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(i==1)
				printf("*");
			else if(i==j)
				printf("*");
			else if(j<=n-i+1 && j>= i+1 ) 
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	

	return 0;
}
