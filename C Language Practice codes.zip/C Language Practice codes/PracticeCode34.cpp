#include <stdio.h>
int main()
{
	
	int i, j, n=9;

	for(i=1;i<=n/2+1;i++)
	{
		for(j=1;j<=n;j++)
		{
			if(j >= ((n/2 + 1)+1)-i && j <= (((n/2 + 1))-1)+i)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}
	for(i=1;i<=n/2+1;i++)
	{
		for(j=1;j<=n;j++)
		{
			if( j<= n-i && j>= i+1)
				printf("*");
			else
				printf(" ");
		}
		printf("\n");
	}	

	return 0;
}
