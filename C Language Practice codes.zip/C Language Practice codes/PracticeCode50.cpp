#include<stdio.h>
int division(int,int);
int multiplication(int,int);
int addition(int,int);
int subtraction(int,int);
int main()
{
	int a,b,n,answer;
	
	printf("Enter value a: ");
	scanf("%d", &a);
	printf("Enter value b: ");
	scanf("%d", &b);
	
	printf("For division select 1 \n");
	printf("For multiplication select 2\n");
	printf("For addition select 3\n");
	printf("For subtraction select 4\n");
	printf("Select 0 to stop!\n");
	scanf("%d", &n);
	
	while(n!=0)
	{
		if(n==1)
			printf("\nAnswer: %d\n", division(a,b));
		else if(n==2)
			printf("\nAnswer: %d\n", multiplication(a,b));
		else if(n==3)
			printf("\nAnswer: %d\n", multiplication(a,b));
		else if(n==4)
			printf("\nAnswer: %d\n", multiplication(a,b));
			
		printf("For division select 1\n");
		printf("For multiplication select 2\n");
		printf("For addition select 3\n");
		printf("For subtraction select 4\n");
		printf("Select 0 to stop!\n");
		
		scanf("%d", &n);
	}
	
	return 0;
}
int division(int a,int b)
{
	return (float)a/b;
}
int multiplication(int a,int b)
{
	return a*b;
}
int addition(int a,int b)
{
	return a+b;
}
int subtraction(int a,int b)
{
	return a-b;
}
