#include<iostream>
using namespace std;
int main(){
	
	int num = 97;
	char ch = (char)num;
	
	cout<<ch;
	
	return 0;
}
